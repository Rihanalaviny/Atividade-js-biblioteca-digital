import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

export default function Rihanna() {
  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>J. K. Rowling</Text>
        <View>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            <View>
              <Image
                resizeMode={'stretch'}
                style={estilo.img}
                source={require('../../assets/autores/rowling.jpg')}
              />
            </View>

          </ScrollView>
        </View>
        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
         J. K. Rowling é uma escritora britânica, nascida em 31 de julho de 1965, na Inglaterra. Ficou mundialmente famosa por criar a série de livros Harry Potter, que conta a história de um jovem bruxo e seus amigos. Seus livros fizeram muito sucesso e foram adaptados para o cinema. Rowling tornou-se uma das escritoras mais conhecidas da literatura contemporânea.
          </Text>
        </View>
      </View>
    </ScrollView>
  );    
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#000000',
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 30,
  },
  rotulo: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 20,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});