import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

export default function Antoine() {
  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Antoine de Saint-Exupéry</Text>

        <View>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>

            <View>
              <Image
                resizeMode={'stretch'}
                style={estilo.img}
                source={require('../../assets/autores/Antoine.jpg')}
              />
              
            </View>


          </ScrollView>
        </View>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            Antoine de Saint-Exupéry foi um escritor e piloto francês, nascido em 1900, em Lyon. Ficou famoso principalmente por escrever O Pequeno Príncipe, uma obra que fala sobre amizade, amor e os valores da vida. Também escreveu outros livros inspirados em suas experiências como piloto. Durante a Segunda Guerra Mundial, participou de missões aéreas e desapareceu em 1944, durante um voo sobre o Mar Mediterrâneo.

          </Text>
        </View>

      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
  },

  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },

  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#000000',
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 30,
  },

  rotulo: {
    color: '#ffffff',
    textAlign: 'left',
    marginTop: 20,
    fontSize: 20,
  },

  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 8,
  },

  textoResumo: {
    fontSize: 19,
  },
});