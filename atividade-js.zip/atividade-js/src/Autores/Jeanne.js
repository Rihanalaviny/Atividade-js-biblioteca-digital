import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
export default function TaylorSwift() {
  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Jeanne-Marie Leprince de Beaumont</Text>
        <View>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            <View>
              <Image
                resizeMode={'stretch'}
                style={estilo.img}
                source={require('../../assets/autores/Jeanne-Marie_Leprince_de_Beaumont.jpg')}
              />
            </View>

          </ScrollView>
        </View>
        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            Jeanne-Marie Leprince de Beaumont foi uma escritora e educadora francesa, nascida em 26 de abril de 1711, em Rouen, na França. Ficou famosa por sua versão do conto A Bela e a Fera, publicada em 1756. Suas obras ensinavam valores como bondade, respeito e generosidade. Ela faleceu em 8 de setembro de 1780, deixando uma importante contribuição para a literatura infantil.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#000000',
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 30,
  },
  rotulo: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 20,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});