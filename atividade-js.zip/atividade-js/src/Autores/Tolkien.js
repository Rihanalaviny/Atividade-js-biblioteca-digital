import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

export default function RitaLee() {
  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>J. R. R. Tolkien</Text>
        <View>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            <View>
              <Image
                resizeMode={'stretch'}
                style={estilo.img}
                source={require('../../assets/autores/JRR-Tolkien.webp')}
              />
            </View>

          </ScrollView>
        </View>
        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
         J. R. R. Tolkien foi um escritor, professor e filólogo britânico, nascido em 3 de janeiro de 1892, na África do Sul. Ficou famoso por escrever O Hobbit e O Senhor dos Anéis, obras de fantasia que conquistaram leitores no mundo todo. Também criou línguas e mundos imaginários para suas histórias. Tolkien faleceu em 2 de setembro de 1973, na Inglaterra, deixando uma grande contribuição para a literatura fantástica.
          </Text>
        </View>
      </View>
    </ScrollView>
  );    
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#000000',
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 30,
  },
  rotulo: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 20,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});