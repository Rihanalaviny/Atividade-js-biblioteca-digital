import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function Autor(props) {
  return (
    <View style={estilo.container}>
      <Text style={estilo.titulo}> Autores Populares</Text>

      <FlatList
        data={artistas}
        renderItem={({ item }) => (
          <View style={estilo.artista}>
            <TouchableOpacity
              onPress={() => {
                props.navigation.navigate(item.buttom);
              }}>
              <Text style={estilo.txtArtista}> {item.nome}</Text>
            </TouchableOpacity>
            <View style={estilo.rede}>

            
            </View>
          </View>
        )}
      />
    </View>
  );
}

const artistas = [
  {
    uid: 1,
    nome: 'Antoine de Saint-Exupéry',
    like: 234,
    seguidores: 2345,
    buttom: 'Antoine',
  },
  {
    uid: 1,
    nome: 'J. K. Rowling.',
    like: 876,
    seguidores: 9876,
    buttom: 'Rowling',
  },
  {
    uid: 3,
    nome: 'J. R. R. Tolkien.',
    like: 2345,
    seguidores: 6789,
    buttom: 'Tolkien',
  },
  {
    uid: 4,
    nome: 'Jeanne-Marie Leprince de Beaumont',
    like: 5674,
    seguidores: 8945,
    buttom: 'Jeanne',
  },
];

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5EBE6',
  },
  artista: {
    backgroundColor: '#8B5A2B',
    justifyContent: 'center',
    marginHorizontal: 20,
    marginVertical: 10,
    padding: 18,
    borderRadius: 8,
    alignContent: 'center',
  },
  titulo: {
    fontSize: 28,
    textAlign: 'center',
    color: '#4A2E1B',
    fontWeight: 700,
    marginVertical: 30,
  },
  rede: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  txtArtista: {
    fontSize: 18,
    color: '#FFF8F0'
  },
});
