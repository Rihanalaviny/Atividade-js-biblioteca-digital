import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function Livros(props) {
  return (
    <View style={estilo.container}>
      <Text style={estilo.titulo}> Leituras Populares</Text>

      <FlatList
        data={musicas}
        renderItem={({ item }) => (
          <View style={estilo.musicas}>
            <TouchableOpacity
              onPress={() => {
                props.navigation.navigate(item.buttom);
              }}>
              <Text style={estilo.txtMusicas}> {item.nome}</Text>
            </TouchableOpacity>
            <View style={estilo.rede}>
              <Text style={estilo.curtidas}>
                <MaterialCommunityIcons
                  name="thumb-up"
                  size={20}
                  color={'#F00'}
                />
                {item.like} Leram
              </Text>
            
            </View>
          </View>
        )}
      />
    </View>
  );
}

const musicas = [
  {
    uid: 1,
    nome: 'O Pequeno Principe',
    like: 234,
    seguidores: 2345,
    buttom: 'OPequenoPrincipe',
  },
  {
    uid: 2,
    nome: 'Harry Potter',
    like: 876,
    seguidores: 9876,
    buttom: 'HarryPotter',
  },
  {
    uid: 3,
    nome: 'O Senhor dos Anéis',
    like: 2345,
    seguidores: 6789,
    buttom: 'OSenhorDosAneis',
  },
  {
    uid: 4,
    nome: 'A Bela e a Fera',
    like: 5674,
    seguidores: 8945,
    buttom: 'ABelaeaFera',
  },
];

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5EBE6',
  },
  musicas: {
    backgroundColor: '#8B5A2B',
    justifyContent: 'center',
    margin: 15,
    padding: 18,
    borderRadius: 8,
    alignContent: 'center',
  },
  titulo: {
    fontSize: 28,
    textAlign: 'center',
    color: '#4A2E1B',
    fontWeight: 'bold',
    marginVertical: 30,
  },
  rede: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  txtMusicas: {
    fontSize: 18,
    color: '#FFF8F0',
  },
});