import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function OPequenoPrincipe() {
  const letra = `O Pequeno Príncipe é um livro escrito por Antoine de Saint-Exupéry e publicado em 1943. A história acompanha um pequeno príncipe que vive em um pequeno asteroide e viaja por diferentes planetas, conhecendo personagens que representam diferentes comportamentos dos adultos.

Durante sua viagem, ele aprende sobre amizade, amor, responsabilidade e sobre o que realmente é importante na vida. Ao chegar à Terra, conhece uma raposa, que lhe ensina uma importante lição sobre os laços que criamos com as pessoas.

A obra é uma história aparentemente simples, mas apresenta reflexões profundas sobre a vida, os sentimentos e as relações humanas.
`;

return (
  <ScrollView>
    <View style={styles.container}>
      <Text style={styles.titulo}>O Pequeno Principe</Text>

      <Text style={styles.subtitulo}>
        Antoine de Saint-Exupéry
      </Text>

<View style={styles.resumo}>
        <Text style={styles.textoResumo}>
          {letra}
        </Text>
        </View>
    </View>
  </ScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#1f3b7',
    marginBottom: 20,
  },
   resumo: {
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 19,
    lineHeight: 32,
    color: '#222',
  },

});