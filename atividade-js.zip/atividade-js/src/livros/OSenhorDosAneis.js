import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function OSenhorDosAneis() {
  const letra = `O Senhor dos Anéis é uma obra de fantasia escrita pelo autor britânico J. R. R. Tolkien. A história acompanha Frodo Bolseiro, um hobbit que recebe a missão de destruir um poderoso anel capaz de colocar toda a Terra-média sob o domínio do mal.

Frodo parte em uma jornada acompanhado por seus amigos e outros personagens, formando a Sociedade do Anel. Durante a aventura, eles enfrentam perigos, criaturas e batalhas enquanto tentam impedir que o anel caia nas mãos de Sauron, o Senhor do Escuro.

A obra aborda temas como amizade, coragem, lealdade, sacrifício e a luta entre o bem e o mal. O Senhor dos Anéis se tornou uma das obras de fantasia mais famosas da literatura e também ganhou adaptações para o cinema.
`;

return (
  <ScrollView>
    <View style={styles.container}>
      <Text style={styles.titulo}>O Senhor Dos Aneis</Text>

      <Text style={styles.subtitulo}>
        J. R. R. Tolkien.
      </Text>

      <View style={styles.resumo}>
        <Text style={styles.textoResumo}>
          {letra}
        </Text>
      </View>
    </View>
  </ScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#1f3b7',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 19,
    lineHeight: 32,
    color: '#222',
  },
});