import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function ABelaeaFera() {
  const letra = `A Bela e a Fera é um conto de fadas de origem francesa. A versão mais conhecida foi escrita por Jeanne-Marie Leprince de Beaumont e publicada em 1756.

A história acompanha Bela, uma jovem inteligente e bondosa que acaba vivendo em um castelo com uma Fera. Com o passar do tempo, Bela percebe que, por trás da aparência assustadora, existe alguém gentil e de bom coração.

A obra fala sobre amor, amizade, coragem e sobre a importância de não julgar alguém pela aparência. A Bela e a Fera se tornou uma das histórias mais conhecidas do mundo e ganhou diversas adaptações para o cinema, incluindo a famosa animação da Disney.
`;

return (
  <ScrollView>
    <View style={styles.container}>
      <Text style={styles.titulo}>A Bela e a Fera</Text>

      <Text style={styles.subtitulo}>
        Jeanne-Marie Leprince de Beaumont
      </Text>

      <View style={styles.resumo}>
        <Text style={styles.textoResumo}>
          {letra}
        </Text>
      </View>
    </View>
  </ScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#1f3b7',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 19,
    lineHeight: 32,
    color: '#222',
  },
});