import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function HarryPotter() {
  const letra = `Harry Potter é uma série de livros escrita pela autora britânica J. K. Rowling. A história acompanha Harry Potter, um garoto que descobre, aos 11 anos, que é um bruxo e que possui uma ligação com o mundo da magia.

Harry passa a estudar na Escola de Magia e Bruxaria de Hogwarts, onde faz amizade com Rony Weasley e Hermione Granger. Ao longo da história, os três enfrentam diversos desafios e descobrem mais sobre o passado de Harry e sobre o bruxo das trevas Lord Voldemort.

A série aborda temas como amizade, coragem, lealdade e a luta entre o bem e o mal. Harry Potter se tornou uma das séries literárias mais conhecidas do mundo e também ganhou adaptações para o cinema.
`;

return (
  <ScrollView>
    <View style={styles.container}>
      <Text style={styles.titulo}>Harry Potter</Text>

      <Text style={styles.subtitulo}>
        J. K. Rowling.
      </Text>

      <View style={styles.resumo}>
        <Text style={styles.textoResumo}>
          {letra}
        </Text>
      </View>
    </View>
  </ScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebdccb',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#1f3b7',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 19,
    lineHeight: 32,
    color: '#222',
  },
});