import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import OPequenoPrincipe from './livros/OPequenoPrincipe';
import OSenhorDosAneis from './livros/OSenhorDosAneis';
import HarryPotter from './livros/HarryPotter';
import ABelaeaFera from './livros/ABelaeaFera';
import Livros from './pages/Livros';

const Stack = createStackNavigator();

export default function App() {
  return (
      <Stack.Navigator>
        <Stack.Screen 
          name="Livros" 
          component={Livros} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="OPequenoPrincipe" 
          component={OPequenoPrincipe} 
          options={{ title: "O Pequeno Principe" }} 
        />
        <Stack.Screen 
          name="OSenhorDosAneis" 
          component={OSenhorDosAneis} 
          options={{ title: "O Senhor Dos Aneis" }} 
        />
        <Stack.Screen 
          name="HarryPotter" 
          component={HarryPotter} 
          options={{ title: "Harry Potter" }} 
        />
        <Stack.Screen 
          name="ABelaeaFera" 
          component={ABelaeaFera} 
          options={{ title: "A Bela e a Fera" }} 
        />
      </Stack.Navigator>
  );
}