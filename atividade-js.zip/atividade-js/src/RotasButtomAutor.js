import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';

import { createStackNavigator } from '@react-navigation/stack';

import Antoine from './Autores/Antoine';
import Rowling from './Autores/Rowling';
import Tolkien from './Autores/Tolkien';
import Jeanne from './Autores/Jeanne';
import Autor from './pages/autores';

const Stack = createStackNavigator();

export default function RotasButtomAutor() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="Autores" 
        component={Autor} 
        options={{ headerShown: false }} 
      />
      <Stack.Screen 
        name="Antoine" 
        component={Antoine} 
        options={{ title: "Antoine de Saint-Exupéry" }} 
      />
      <Stack.Screen 
        name="Rowling" 
        component={Rowling} 
        options={{ title: "J. K. Rowling." }} 
      />
      <Stack.Screen 
        name="Tolkien" 
        component={Tolkien} 
        options={{ title: "J. R. R. Tolkien." }} 
      />
      <Stack.Screen 
        name="Jeanne" 
          component={Jeanne}
        options={{ title: "Jeanne-Marie Leprince de Beaumont" }} 
      />
    </Stack.Navigator>
  );
}
